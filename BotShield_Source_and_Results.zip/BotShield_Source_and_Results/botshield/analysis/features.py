"""Per-account feature extraction from fox8-23-slim.ndjson -> results/account_features.csv, results/hours.csv.
Usage: python3 analysis/features.py <fox8-23-slim.ndjson>"""
import json, numpy as np, pandas as pd
from email.utils import parsedate_to_datetime
import sys, os
SRC=sys.argv[1] if len(sys.argv)>1 else "fox8-23-slim.ndjson"
OUT=os.path.join(os.path.dirname(os.path.abspath(__file__)),"..","results")
rows=[]; hours=[]
acc={}
with open(SRC) as f:
    for line in f:
        line=line.strip()
        if not line: continue
        r=json.loads(line)
        uid=r["user_id"]
        if uid in acc:   # loader: account row kept from first record, tweets of later record still inserted
            acc[uid]["user_tweets"]=acc[uid]["user_tweets"]+r.get("user_tweets",[])
        else:
            acc[uid]=r
for uid,r in acc.items():
    if True:
        tw=r.get("user_tweets",[])
        ts=[]; 
        for t in tw:
            try: ts.append(parsedate_to_datetime(t["created_at"]))
            except Exception: pass
        ts.sort()
        gaps=np.diff([x.timestamp() for x in ts])/3600.0 if len(ts)>1 else np.array([])
        texts=[t.get("text") or "" for t in tw]
        n=len(tw)
        ents=[t.get("entities",{}) for t in tw]
        row=dict(user_id=uid,label=r["label"],source=r["dataset"],n_tweets=n,
            n_gaps=len(gaps),
            mean_gap=gaps.mean() if len(gaps) else np.nan,
            sd_gap=gaps.std(ddof=1) if len(gaps)>1 else np.nan,
            dup_ratio=(n-len(set(texts)))/n if n else np.nan,
            text_len=np.mean([len(x) for x in texts]) if n else np.nan,
            mentions=np.mean([e.get("mention_count",0) for e in ents]) if n else np.nan,
            hashtags=np.mean([e.get("hashtag_count",0) for e in ents]) if n else np.nan,
            urls=np.mean([e.get("url_count",0) for e in ents]) if n else np.nan,
            fav=np.mean([t.get("favorite_count",0) or 0 for t in tw]) if n else np.nan,
            rt=np.mean([t.get("retweet_count",0) or 0 for t in tw]) if n else np.nan)
        rows.append(row)
        for x in ts: hours.append((r["label"],x.hour))
df=pd.DataFrame(rows)
df["cv"]=df.sd_gap/df.mean_gap
df.to_csv(os.path.join(OUT,"account_features.csv"),index=False)
pd.DataFrame(hours,columns=["label","hour"]).to_csv(os.path.join(OUT,"hours.csv"),index=False)
print("accounts",len(df), df.label.value_counts().to_dict())
print(df.source.value_counts().to_dict())
print("tweets", df.n_tweets.sum())
# reproduce Table 2 / Table 3
ok=df[(df.n_gaps>=3)&(df.mean_gap>0)]
print("gap/CV (accounts with >=3 gaps):", ok.groupby("label").agg(n=("mean_gap","size"),gap=("mean_gap","mean"),cv=("cv","mean")).round(3).to_dict("index"))
print("fav mean of account means:", df.groupby("label").fav.mean().round(2).to_dict())
pred_bot=df.fav<1.0
print(pd.crosstab(df.label,pred_bot))
