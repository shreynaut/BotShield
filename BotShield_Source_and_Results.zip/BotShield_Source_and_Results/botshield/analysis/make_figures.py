"""Regenerates Figs. 1-8 of the paper from results/account_features.csv and results/hours.csv.
Run after features.py:  python3 analysis/make_figures.py"""
import numpy as np, pandas as pd, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Polygon
plt.rcParams.update({"font.family":"serif","font.serif":["Times New Roman","Liberation Serif","DejaVu Serif"],"font.size":10,"axes.spines.top":False,"axes.spines.right":False,"figure.dpi":200})
B,H="#333333","#9a9a9a"
import os
R=os.path.join(os.path.dirname(os.path.abspath(__file__)),"..","results")+"/"
FD=R+"figures/"
df=pd.read_csv(R+"account_features.csv"); hrs=pd.read_csv(R+"hours.csv")
ok=df[(df.n_gaps>=3)&(df.mean_gap>0)]
bot=lambda d:d[d.label=="bot"]; hum=lambda d:d[d.label=="human"]
# Fig 3
fig,ax=plt.subplots(1,3,figsize=(7.2,2.6))
spec=[("(a) Posting interval","Mean gap between tweets (hours)",[6.85,62.23],"{:.2f}"),("(b) Engagement received","Favourites per tweet (mean)",[0.0812,457.11],"{:.2f}"),("(c) Exact duplication","Exact-duplicate ratio (mean)",[0.0001,0.0071],"{:.4f}")]
for a,(t,yl,v,f) in zip(ax,spec):
    a.bar([0,1],v,color=[H,"#4d4d4d"],width=.55)
    for i,x in enumerate(v): a.text(i,x,f.format(x),ha="center",va="bottom",fontsize=8)
    a.set_xticks([0,1]); a.set_xticklabels(["Bot\n(n = 1,140)","Human\n(n = 1,139)"],fontsize=8.5); a.set_ylabel(yl,fontsize=8.5); a.set_title(t,fontsize=9.5); a.set_ylim(0,max(v)*1.15)
plt.tight_layout(); plt.savefig(FD+"fig3.png"); plt.close()
# Fig 4
def hist(ax,col,d,bins,tf=lambda x:x):
    for f,c,l,h in((bot,B,"Bot",None),(hum,H,"Human","//")):
        ax.hist(tf(f(d)[col].values),bins=bins,alpha=.75,color=c,label=l,hatch=h,edgecolor="white" if h is None else "#555",linewidth=.4)
fig,ax=plt.subplots(1,3,figsize=(7.2,2.6))
hist(ax[0],"mean_gap",ok,np.linspace(-2.5,3.5,31),np.log10); ax[0].set_xlabel("log$_{10}$ mean gap (hours)")
hist(ax[1],"cv",ok,np.linspace(0,8,33)); ax[1].set_xlabel("Gap CV (SD / mean of gaps)")
hist(ax[2],"fav",df,np.linspace(0,4,33),lambda x:np.log10(1+x)); ax[2].set_xlabel("log$_{10}$(1 + favourites per tweet)")
for a,t in zip(ax,"abc"): a.set_title(f"({t})",fontsize=9.5); a.tick_params(labelsize=8.5)
ax[0].set_ylabel("Number of accounts"); ax[0].legend(frameon=False,fontsize=8.5)
plt.tight_layout(); plt.savefig(FD+"fig4.png"); plt.close()
# Fig 5
src=["fox8","botometer-feedback","gilani-17","midterm-2018","varol-icwsm"]
lab=["fox8\n(bot)","botometer-\nfeedback","gilani-\n17","midterm-\n2018","varol-\nicwsm"]
fig,ax=plt.subplots(1,3,figsize=(7.2,2.8))
spec=[("fav",df,"(a) Favourites per tweet","Median favourites per tweet"),("cv",ok,"(b) Gap CV","Median gap CV"),("mean_gap",ok,"(c) Mean gap","Median mean gap (hours)")]
for a,(c,d,t,yl) in zip(ax,spec):
    m=[d[d.source==s][c].median() for s in src]
    a.bar(range(5),m,color=[B]+[H]*4,edgecolor="#222",linewidth=.5)
    for i,v in enumerate(m): a.text(i,v,f"{v:.2f}" if v<10 else f"{v:.1f}",ha="center",va="bottom",fontsize=7.5)
    a.set_xticks(range(5)); a.set_xticklabels(lab,fontsize=7); a.set_title(t,fontsize=9.5); a.set_ylabel(yl,fontsize=8.5); a.tick_params(axis="y",labelsize=8.5)
plt.tight_layout(); plt.savefig(FD+"fig5.png"); plt.close()
# Fig 6
h=pd.crosstab(hrs.hour,hrs.label,normalize="columns")*100
fig,ax=plt.subplots(figsize=(4.8,2.6))
ax.plot(h.index,h["bot"],"-o",color=B,ms=3,label="Bot"); ax.plot(h.index,h["human"],"--s",color="#777",ms=3,label="Human")
ax.set_xlabel("Hour of day (UTC)"); ax.set_ylabel("Share of tweets (%)"); ax.set_xticks(range(0,24,3)); ax.set_ylim(0,6.5); ax.legend(frameon=False)
plt.tight_layout(); plt.savefig(FD+"fig6.png"); plt.close()
# Fig 7
cols=["mean_gap","cv","dup_ratio","text_len","mentions","hashtags","urls","fav","rt"]
nm=["Mean gap","Gap CV","Exact-dup. ratio","Text length","Mentions","Hashtags","URLs","Favourites","Retweets"]
d2=df.copy(); d2["bot"]=(d2.label=="bot").astype(int)
C=d2[cols+["bot"]].corr(method="spearman").values
fig,ax=plt.subplots(figsize=(5.2,4.4))
im=ax.imshow(C,cmap="Greys",vmin=-1,vmax=1)
names=nm+["Bot label"]; ax.set_xticks(range(10)); ax.set_yticks(range(10)); ax.set_xticklabels(names,rotation=45,ha="right",fontsize=8); ax.set_yticklabels(names,fontsize=8)
for i in range(10):
    for j in range(10): ax.text(j,i,f"{C[i,j]:.2f}",ha="center",va="center",fontsize=7,color="white" if C[i,j]>.4 else "black")
for s in ax.spines.values(): s.set_visible(False)
cb=plt.colorbar(im,fraction=.046,pad=.03); cb.set_label("Spearman ρ",fontsize=8.5); plt.tight_layout(); plt.savefig(FD+"fig7.png"); plt.close()
# Fig 8
y=(df.label=="bot").values; fav=df.fav.values
def prf(t):
    p_=fav<t; tp=(p_&y).sum(); fp=(p_&~y).sum(); fn=(~p_&y).sum()
    P=tp/(tp+fp) if tp+fp else np.nan; R=tp/(tp+fn); return P,R,(2*P*R/(P+R) if P==P and P+R>0 else np.nan),fp/(~y).sum()
grid=np.logspace(-2,2,200); S=np.array([prf(t) for t in grid])
taus=np.unique(np.concatenate([np.sort(np.unique(fav)),[1e-3]]))
fig,ax=plt.subplots(1,2,figsize=(7.2,3.0))
a=ax[0]; a.semilogx(grid,S[:,0],"-",color="#777",label="Precision"); a.semilogx(grid,S[:,1],"--",color="#aaa",label="Recall"); a.semilogx(grid,S[:,2],"-",color=B,lw=1.6,label="F1")
a.axvline(1.0,color="k",ls=":",lw=.8); a.text(1.1,.12,"τ = 1.0",fontsize=8.5); a.set_xlabel("Threshold τ (favourites per tweet)"); a.set_ylabel("Score"); a.set_ylim(0,1.05); a.legend(frameon=False,fontsize=8.5,loc="lower right"); a.set_title("(a)",fontsize=9.5)
T=np.array([prf(t) for t in taus]); fpr=np.r_[0,T[:,3],1]; tpr=np.r_[0,T[:,1],1]; o=np.argsort(fpr,kind="stable"); fpr,tpr=fpr[o],tpr[o]
auc=np.trapezoid(tpr,fpr)
b=ax[1]; b.plot(fpr,tpr,color=B,label=f"Favourites rule (AUC = {auc:.3f})"); b.plot([0,1],[0,1],":",color="#888",label="Chance"); b.set_xlabel("False-positive rate"); b.set_ylabel("True-positive rate"); b.legend(frameon=False,fontsize=8.5,loc="lower right"); b.set_title("(b)",fontsize=9.5)
plt.tight_layout(); plt.savefig(FD+"fig8.png"); plt.close()
# Fig 1 architecture
fig,ax=plt.subplots(figsize=(6.4,6.6)); ax.set_xlim(0,100); ax.set_ylim(0,100); ax.axis("off")
def box(x,y,w,h,t,s=None,fc="white"):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle="round,pad=0.4,rounding_size=1.2",fc=fc,ec="black",lw=1.4))
    ax.text(x+w/2,y+h-(2.2 if s or h>20 else h/2),t,ha="center",va="top" if (s or h>20) else "center",fontsize=11,fontweight="bold")
    if s: ax.text(x+w/2,y+h-8.2,s,ha="center",va="top",fontsize=9.5,style="italic",color="#333")
def arrow(x,y0,y1): ax.annotate("",xy=(x,y1),xytext=(x,y0),arrowprops=dict(arrowstyle="-|>",lw=1.4,color="black"))
X,W=4,72
box(X,84,W,14,"Administrator dashboard (Thymeleaf)","risk-score list, factor-breakdown view",fc="#ececec"); arrow(X+W/2,84,78)
box(X,64,W,14,"REST controller","/api/accounts, /api/accounts/{id}/risk"); arrow(X+W/2,64,58)
box(X,36,W,22,"Scoring service")
for i,t in enumerate(["Behavioural\nfeatures","Content\nfeatures","Network\nfeatures"]):
    bx=X+3+i*23.5; ax.add_patch(FancyBboxPatch((bx,38.5),21,10,boxstyle="round,pad=0.3,rounding_size=1",fc="#f4f4f4",ec="#444",lw=1)); ax.text(bx+10.5,43.5,t,ha="center",va="center",fontsize=9.5)
arrow(X+W/2,36,30)
box(X,10,W,20,"Repository layer (Hibernate / JPA)","AccountRepository, TweetRepository"); arrow(X+W/2,10,5.5)
box(X,-10,W,15,"PostgreSQL","accounts, tweets, connections",fc="#ececec")
ax.annotate("",xy=(X+W+1,-2.5),xytext=(86,-2.5),arrowprops=dict(arrowstyle="-|>",lw=1.2,color="#555"))
ax.text(87,-2.5,"fox8-23\n2,279 accounts\n111,905 tweets",fontsize=9.5,style="italic",color="#333",va="center")
ax.set_ylim(-13,100); ax.set_xlim(0,112)
plt.savefig(FD+"fig1.png",bbox_inches="tight",dpi=200); plt.close()
# Fig 2 flowchart
fig,ax=plt.subplots(figsize=(6.4,6.2)); ax.set_xlim(0,100); ax.set_ylim(0,100); ax.axis("off")
steps=["Raw NDJSON record\n(account + tweets)","Parse JSON line,\nvalidate required fields",None,"Insert account\n(ON CONFLICT: skip duplicate ID)","Insert tweets,\ncompute entity counts","Extract features:\nbehavioural, content, network","Weighted fusion over available\nsignals → Risk(a), factor breakdown","Persist score,\nrender on dashboard"]
ys=np.linspace(94,6,8); bw,bh=44,9
for t,y in zip(steps,ys):
    if t is None:
        ax.add_patch(Polygon([(32,y),(50,y+5.5),(68,y),(50,y-5.5)],fc="#f0f0f0",ec="black",lw=1.4)); ax.text(50,y,"Fields\nvalid?",ha="center",va="center",fontsize=10)
        ax.text(70,y+1,"no → log error,\nskip record (Sec. 4.4)",fontsize=9.5,style="italic",color="#333",va="center")
    else:
        ax.add_patch(FancyBboxPatch((50-bw/2,y-bh/2),bw,bh,boxstyle="round,pad=0.3,rounding_size=1",fc="white",ec="black",lw=1.4)); ax.text(50,y,t,ha="center",va="center",fontsize=10)
for i in range(7):
    y0=ys[i]-(5.5 if steps[i] is None else bh/2+.3); y1=ys[i+1]+(5.5 if steps[i+1] is None else bh/2+.3)
    ax.annotate("",xy=(50,y1),xytext=(50,y0),arrowprops=dict(arrowstyle="-|>",lw=1.3,color="black"))
ax.set_xlim(8,112)
plt.savefig(FD+"fig2.png",bbox_inches="tight",dpi=200); plt.close()
