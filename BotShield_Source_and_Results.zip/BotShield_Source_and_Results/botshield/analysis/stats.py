"""Statistics behind Figs. 4-8: per-source medians, hour profile, threshold sweep, AUC, Spearman, Mann-Whitney.
Run after features.py:  python3 analysis/stats.py"""
import numpy as np, pandas as pd
from scipy.stats import rankdata, spearmanr, mannwhitneyu
import os
W=os.path.join(os.path.dirname(os.path.abspath(__file__)),"..","results")+"/"
df=pd.read_csv(W+"account_features.csv"); hrs=pd.read_csv(W+"hours.csv")
print("== per-source medians (per-account values) ==")
g=df[(df.n_gaps>=3)&(df.mean_gap>0)].groupby("source").agg(n=("user_id","size"),med_gap=("mean_gap","median"),med_cv=("cv","median"))
g["med_fav"]=df.groupby("source").fav.median(); g["mean_cv"]=df[(df.n_gaps>=3)&(df.mean_gap>0)].groupby("source").cv.mean()
g["mean_gap"]=df[(df.n_gaps>=3)&(df.mean_gap>0)].groupby("source").mean_gap.mean()
print(g.round(3))
print("\n== hour of day (UTC) share of tweets, peak/trough ==")
h=pd.crosstab(hrs.hour,hrs.label,normalize="columns")
print(h.round(3).T.to_string())
print("peak hr", h.idxmax().to_dict(), "max share", h.max().round(3).to_dict(), "min share", h.min().round(3).to_dict())
print("\n== baseline threshold sweep ==")
y=(df.label=="bot").values; fav=df.fav.values
def prf(tau):
    pred=fav<tau
    tp=(pred&y).sum(); fp=(pred&~y).sum(); fn=(~pred&y).sum()
    p=tp/(tp+fp) if tp+fp else np.nan; r=tp/(tp+fn); f=2*p*r/(p+r) if p==p and p+r>0 else np.nan
    return p,r,f
for tau in [0.01,0.1,0.5,1,2,5,10,50]:
    print(tau, [round(x,3) for x in prf(tau)])
taus=np.unique(np.concatenate([[0],np.sort(np.unique(fav))]))
best=max(((prf(t)[2],t) for t in taus if t>0), key=lambda x:x[0]); print("best F1",best)
# AUC (score = -fav, higher => bot)
sc=-fav; rk=rankdata(sc); n1=y.sum(); n0=(~y).sum()
auc=(rk[y].sum()-n1*(n1+1)/2)/(n1*n0); print("AUC",round(auc,4))
print("\n== Spearman with label (bot=1) ==")
cols=["mean_gap","cv","dup_ratio","text_len","mentions","hashtags","urls","fav","rt"]
d2=df.copy(); d2["bot"]=y.astype(int)
print(d2[cols+["bot"]].corr(method="spearman")["bot"].round(3).to_dict())
print("\nMWU p-values (two-sided):")
for c in cols:
    a=df.loc[y,c].dropna(); b=df.loc[~y,c].dropna()
    print(c, "bot med %.3f human med %.3f p=%.2e"%(a.median(),b.median(),mannwhitneyu(a,b).pvalue))
print("\nzero-fav share:", df.assign(z=df.fav==0).groupby("label").z.mean().round(3).to_dict())
print("humans fav<1 by source:", df[(df.label=='human')].assign(l=lambda x:x.fav<1).groupby("source").l.mean().round(3).to_dict())
