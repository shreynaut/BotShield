"""
Reference loader: fox8-23-slim.ndjson -> PostgreSQL (accounts, tweets).

This is a verification/reference implementation — it proves the dataset maps
cleanly onto the schema. The actual application loader will be a Spring Boot
CommandLineRunner (Java) that does the same thing via Hibernate/JPA.
"""
import json
import sys
import psycopg2
from email.utils import parsedate_to_datetime

DATA_FILE = sys.argv[1] if len(sys.argv) > 1 else "fox8-23-slim.ndjson"
DB_NAME = sys.argv[2] if len(sys.argv) > 2 else "botshield"

conn = psycopg2.connect(
    dbname=DB_NAME, user="postgres", password="botshield",
    host="localhost", port=5432,
)
cur = conn.cursor()

def parse_twitter_date(s):
    # Twitter API v1.1 format: "Wed Apr 18 14:09:01 +0000 2018"
    return parsedate_to_datetime(s)

accounts_loaded = 0
tweets_loaded = 0
errors = []

with open(DATA_FILE, "r", encoding="utf-8") as f:
    for line_no, line in enumerate(f, 1):
        line = line.strip()
        if not line:
            continue
        cur.execute("SAVEPOINT rec")          # per-record savepoint: one bad record never aborts the load
        try:
            rec = json.loads(line)
            user_id = rec["user_id"]
            label = rec["label"]
            dataset = rec["dataset"]
            tweets = rec.get("user_tweets", [])

            cur.execute(
                """INSERT INTO accounts (external_user_id, label, source_dataset, tweet_count)
                   VALUES (%s, %s, %s, %s)
                   ON CONFLICT (external_user_id) DO NOTHING
                   RETURNING id""",
                (user_id, label, dataset, len(tweets)),
            )
            row = cur.fetchone()
            if row is None:
                # already existed (shouldn't happen with unique dataset, but stay safe)
                cur.execute("SELECT id FROM accounts WHERE external_user_id = %s", (user_id,))
                row = cur.fetchone()
            account_id = row[0]
            accounts_loaded += 1

            for t in tweets:
                try:
                    posted_at = parse_twitter_date(t["created_at"])
                except Exception:
                    posted_at = None
                ents = t.get("entities", {})
                cur.execute(
                    """INSERT INTO tweets
                       (account_id, external_tweet_id, posted_at, text, retweet_count,
                        favorite_count, in_reply_to_status_id, hashtag_count, url_count, mention_count)
                       VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
                    (
                        account_id, t["id"], posted_at, t.get("text"),
                        t.get("retweet_count", 0), t.get("favorite_count", 0),
                        t.get("in_reply_to_status_id"),
                        ents.get("hashtag_count", 0), ents.get("url_count", 0),
                        ents.get("mention_count", 0),
                    ),
                )
                tweets_loaded += 1
            cur.execute("RELEASE SAVEPOINT rec")
        except Exception as e:
            errors.append((line_no, str(e)))
            cur.execute("ROLLBACK TO SAVEPOINT rec")

conn.commit()
print(f"Records processed: {accounts_loaded}")
print(f"Tweets loaded: {tweets_loaded}")
cur.execute("SELECT count(*) FROM accounts")
print(f"Unique accounts in DB: {cur.fetchone()[0]}")
print(f"Errors: {len(errors)}")
if errors[:5]:
    print("Sample errors:", errors[:5])

cur.close()
conn.close()
