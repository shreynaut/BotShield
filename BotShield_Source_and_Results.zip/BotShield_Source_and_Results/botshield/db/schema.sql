-- BotShield core schema
-- Matches the fox8-23 compiled dataset structure (accounts + tweets)

CREATE TABLE IF NOT EXISTS accounts (
    id              BIGSERIAL PRIMARY KEY,
    external_user_id BIGINT NOT NULL UNIQUE,      -- original Twitter user_id from dataset
    label           VARCHAR(10) NOT NULL CHECK (label IN ('bot', 'human')), -- ground truth
    source_dataset  VARCHAR(50) NOT NULL,           -- provenance: fox8 / gilani-17 / etc.
    tweet_count     INT NOT NULL DEFAULT 0,          -- denormalized count, filled after load
    risk_score      DOUBLE PRECISION,                -- filled by scoring engine (Phase 4)
    behavioral_score DOUBLE PRECISION,
    content_score   DOUBLE PRECISION,
    network_score   DOUBLE PRECISION,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS tweets (
    id                  BIGSERIAL PRIMARY KEY,
    account_id          BIGINT NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
    external_tweet_id   BIGINT NOT NULL,
    posted_at           TIMESTAMPTZ,                  -- NULL when created_at cannot be parsed (see tests/run_loader_tests.py)
    text                TEXT,
    retweet_count       INT NOT NULL DEFAULT 0,
    favorite_count      INT NOT NULL DEFAULT 0,
    in_reply_to_status_id BIGINT,
    hashtag_count       INT NOT NULL DEFAULT 0,
    url_count           INT NOT NULL DEFAULT 0,
    mention_count       INT NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_tweets_account_id ON tweets(account_id);
CREATE INDEX IF NOT EXISTS idx_tweets_posted_at ON tweets(posted_at);
CREATE INDEX IF NOT EXISTS idx_accounts_label ON accounts(label);
CREATE INDEX IF NOT EXISTS idx_accounts_source_dataset ON accounts(source_dataset);

-- Network/relationship table — reserved for Phase 2 (graph features).
-- fox8-23 doesn't include follow-graph edges, so this stays empty for now;
-- documented here so the schema is ready when we add a network data source.
CREATE TABLE IF NOT EXISTS connections (
    id              BIGSERIAL PRIMARY KEY,
    source_account_id BIGINT NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
    target_account_id BIGINT NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
    relation_type   VARCHAR(20) NOT NULL DEFAULT 'mention', -- mention / reply / (future: follow)
    UNIQUE(source_account_id, target_account_id, relation_type)
);
