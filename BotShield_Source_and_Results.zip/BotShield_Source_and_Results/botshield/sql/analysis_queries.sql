-- BotShield: queries behind the results in Section 4 (PostgreSQL 16)
\echo '== Q1. Row counts =='
SELECT (SELECT count(*) FROM accounts) AS accounts, (SELECT count(*) FROM tweets) AS tweets, (SELECT count(*) FROM connections) AS connections;

\echo '== Q2. Accounts by label and source dataset =='
SELECT label, source_dataset, count(*) AS accounts FROM accounts GROUP BY 1,2 ORDER BY 1,2;

\echo '== Q3. Table 2: account-level statistics by label =='
WITH tw AS (
  SELECT a.label, count(*) AS n, avg(length(t.text)) AS text_len, avg(t.mention_count) AS mentions,
         avg(t.favorite_count) AS fav, avg(t.retweet_count) AS rt
  FROM tweets t JOIN accounts a ON a.id=t.account_id GROUP BY a.label),
dup AS (
  SELECT label, avg((n - d)::float / n) AS dup_ratio FROM (
    SELECT a.label, count(*) n, count(DISTINCT t.text) d FROM tweets t JOIN accounts a ON a.id=t.account_id GROUP BY a.id, a.label) x GROUP BY label),
gaps AS (
  SELECT account_id, avg(g) AS mean_gap, stddev_samp(g) AS sd_gap, count(*) AS n_gaps FROM (
    SELECT account_id, EXTRACT(EPOCH FROM posted_at - lag(posted_at) OVER (PARTITION BY account_id ORDER BY posted_at))/3600.0 AS g
    FROM tweets WHERE posted_at IS NOT NULL) z WHERE g IS NOT NULL GROUP BY account_id),
gl AS (
  SELECT a.label, avg(mean_gap) AS mean_gap, avg(sd_gap/mean_gap) AS cv FROM gaps g JOIN accounts a ON a.id=g.account_id
  WHERE n_gaps>=3 AND mean_gap>0 GROUP BY a.label)
SELECT tw.label, round(gl.mean_gap::numeric,2) AS mean_gap_h, round(gl.cv::numeric,3) AS mean_cv, round(tw.text_len::numeric,1) AS text_len,
       round(tw.mentions::numeric,3) AS mentions, round(dup.dup_ratio::numeric,4) AS exact_dup, round(tw.fav::numeric,2) AS fav, round(tw.rt::numeric,2) AS retweets
FROM tw JOIN dup USING(label) JOIN gl USING(label) ORDER BY label;

\echo '== Q4. Table 3: baseline rule (mean favourites per tweet < 1.0) confusion matrix =='
WITH f AS (SELECT a.id, a.label, avg(t.favorite_count) AS fav FROM accounts a JOIN tweets t ON t.account_id=a.id GROUP BY a.id, a.label),
c AS (SELECT sum((label='bot' AND fav<1)::int) AS tp, sum((label='bot' AND fav>=1)::int) AS fn,
             sum((label='human' AND fav<1)::int) AS fp, sum((label='human' AND fav>=1)::int) AS tn FROM f)
SELECT tp, fn, fp, tn,
       round(100.0*tp/(tp+fp),1) AS precision_pct, round(100.0*tp/(tp+fn),1) AS recall_pct,
       round(100.0*2*tp/(2*tp+fp+fn),1) AS f1_pct, round(100.0*(tp+tn)/(tp+tn+fp+fn),1) AS accuracy_pct,
       round(100.0*fp/(fp+tn),1) AS fpr_pct FROM c;
