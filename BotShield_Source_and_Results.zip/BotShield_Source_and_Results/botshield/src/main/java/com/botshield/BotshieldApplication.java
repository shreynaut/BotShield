package com.botshield;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BotshieldApplication {
    public static void main(String[] args) {
        SpringApplication.run(BotshieldApplication.class, args);
    }
}
