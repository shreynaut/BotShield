package com.botshield.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * A social media account under evaluation.
 * `label` carries ground truth (bot/human) from the source dataset, used only
 * for evaluation - it is never fed into the scoring model itself.
 */
@Entity
@Table(name = "accounts")
public class Account {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "external_user_id", nullable = false, unique = true)
    private Long externalUserId;

    @Column(name = "label", nullable = false, length = 10)
    private String label; // "bot" | "human" - ground truth, evaluation only

    @Column(name = "source_dataset", nullable = false, length = 50)
    private String sourceDataset;

    @Column(name = "tweet_count", nullable = false)
    private Integer tweetCount = 0;

    @Column(name = "risk_score")
    private Double riskScore;

    @Column(name = "behavioral_score")
    private Double behavioralScore;

    @Column(name = "content_score")
    private Double contentScore;

    @Column(name = "network_score")
    private Double networkScore;

    @Column(name = "created_at", nullable = false)
    private OffsetDateTime createdAt = OffsetDateTime.now();

    @JsonIgnore
    @OneToMany(mappedBy = "account", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    private List<Tweet> tweets = new ArrayList<>();

    public Account() { }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getExternalUserId() { return externalUserId; }
    public void setExternalUserId(Long externalUserId) { this.externalUserId = externalUserId; }

    public String getLabel() { return label; }
    public void setLabel(String label) { this.label = label; }

    public String getSourceDataset() { return sourceDataset; }
    public void setSourceDataset(String sourceDataset) { this.sourceDataset = sourceDataset; }

    public Integer getTweetCount() { return tweetCount; }
    public void setTweetCount(Integer tweetCount) { this.tweetCount = tweetCount; }

    public Double getRiskScore() { return riskScore; }
    public void setRiskScore(Double riskScore) { this.riskScore = riskScore; }

    public Double getBehavioralScore() { return behavioralScore; }
    public void setBehavioralScore(Double behavioralScore) { this.behavioralScore = behavioralScore; }

    public Double getContentScore() { return contentScore; }
    public void setContentScore(Double contentScore) { this.contentScore = contentScore; }

    public Double getNetworkScore() { return networkScore; }
    public void setNetworkScore(Double networkScore) { this.networkScore = networkScore; }

    public OffsetDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(OffsetDateTime createdAt) { this.createdAt = createdAt; }

    public List<Tweet> getTweets() { return tweets; }
    public void setTweets(List<Tweet> tweets) { this.tweets = tweets; }
}
