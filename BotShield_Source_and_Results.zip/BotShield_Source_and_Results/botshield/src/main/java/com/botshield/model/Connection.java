package com.botshield.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;

/**
 * An edge between two accounts (mention/reply, and eventually follow).
 * Reserved for the network-feature phase - the fox8-23 dataset doesn't ship
 * follow-graph edges, so this table is created but unpopulated for now.
 * A later phase can derive mention-based edges from Tweet.mentionCount / text,
 * or load a follow-graph from a different source and join on external_user_id.
 */
@Entity
@Table(name = "connections", uniqueConstraints = {
        @UniqueConstraint(columnNames = {"source_account_id", "target_account_id", "relation_type"})
})
public class Connection {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "source_account_id", nullable = false)
    private Account source;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "target_account_id", nullable = false)
    private Account target;

    @Column(name = "relation_type", nullable = false, length = 20)
    private String relationType = "mention";

    public Connection() { }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Account getSource() { return source; }
    public void setSource(Account source) { this.source = source; }

    public Account getTarget() { return target; }
    public void setTarget(Account target) { this.target = target; }

    public String getRelationType() { return relationType; }
    public void setRelationType(String relationType) { this.relationType = relationType; }
}
