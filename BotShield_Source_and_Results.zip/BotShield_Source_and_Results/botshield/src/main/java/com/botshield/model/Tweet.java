package com.botshield.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;

import java.time.OffsetDateTime;

@Entity
@Table(name = "tweets")
public class Tweet {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "account_id", nullable = false)
    private Account account;

    @Column(name = "external_tweet_id", nullable = false)
    private Long externalTweetId;

    @Column(name = "posted_at")
    private OffsetDateTime postedAt;

    @Column(name = "text", columnDefinition = "TEXT")
    private String text;

    @Column(name = "retweet_count", nullable = false)
    private Integer retweetCount = 0;

    @Column(name = "favorite_count", nullable = false)
    private Integer favoriteCount = 0;

    @Column(name = "in_reply_to_status_id")
    private Long inReplyToStatusId;

    @Column(name = "hashtag_count", nullable = false)
    private Integer hashtagCount = 0;

    @Column(name = "url_count", nullable = false)
    private Integer urlCount = 0;

    @Column(name = "mention_count", nullable = false)
    private Integer mentionCount = 0;

    public Tweet() { }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Account getAccount() { return account; }
    public void setAccount(Account account) { this.account = account; }

    public Long getExternalTweetId() { return externalTweetId; }
    public void setExternalTweetId(Long externalTweetId) { this.externalTweetId = externalTweetId; }

    public OffsetDateTime getPostedAt() { return postedAt; }
    public void setPostedAt(OffsetDateTime postedAt) { this.postedAt = postedAt; }

    public String getText() { return text; }
    public void setText(String text) { this.text = text; }

    public Integer getRetweetCount() { return retweetCount; }
    public void setRetweetCount(Integer retweetCount) { this.retweetCount = retweetCount; }

    public Integer getFavoriteCount() { return favoriteCount; }
    public void setFavoriteCount(Integer favoriteCount) { this.favoriteCount = favoriteCount; }

    public Long getInReplyToStatusId() { return inReplyToStatusId; }
    public void setInReplyToStatusId(Long inReplyToStatusId) { this.inReplyToStatusId = inReplyToStatusId; }

    public Integer getHashtagCount() { return hashtagCount; }
    public void setHashtagCount(Integer hashtagCount) { this.hashtagCount = hashtagCount; }

    public Integer getUrlCount() { return urlCount; }
    public void setUrlCount(Integer urlCount) { this.urlCount = urlCount; }

    public Integer getMentionCount() { return mentionCount; }
    public void setMentionCount(Integer mentionCount) { this.mentionCount = mentionCount; }
}
