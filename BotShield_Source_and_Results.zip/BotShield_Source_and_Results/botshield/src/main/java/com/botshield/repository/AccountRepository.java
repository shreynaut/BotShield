package com.botshield.repository;

import com.botshield.model.Account;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;

public interface AccountRepository extends JpaRepository<Account, Long> {

    Optional<Account> findByExternalUserId(Long externalUserId);

    Page<Account> findByLabel(String label, Pageable pageable);

    Page<Account> findBySourceDataset(String sourceDataset, Pageable pageable);

    @Query("SELECT a FROM Account a WHERE a.riskScore IS NOT NULL AND a.riskScore >= :minRisk ORDER BY a.riskScore DESC")
    Page<Account> findFlaggedAccounts(@Param("minRisk") double minRisk, Pageable pageable);

    long countByLabel(String label);
}
