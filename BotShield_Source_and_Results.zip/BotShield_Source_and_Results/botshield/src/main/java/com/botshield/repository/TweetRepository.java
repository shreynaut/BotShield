package com.botshield.repository;

import com.botshield.model.Tweet;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface TweetRepository extends JpaRepository<Tweet, Long> {

    List<Tweet> findByAccountIdOrderByPostedAtAsc(Long accountId);
}
