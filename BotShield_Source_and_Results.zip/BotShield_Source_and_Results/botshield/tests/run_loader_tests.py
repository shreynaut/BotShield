"""Loader fault-handling tests (Table 5 in the paper).
Builds a 7-line file from real records plus deliberate faults, loads it into a
scratch database and reports what the loader did for each case.
Usage: python3 tests/run_loader_tests.py <fox8-23-slim.ndjson>
"""
import json, subprocess, sys, os, psycopg2
src = sys.argv[1]
lines = []
with open(src) as f:
    for line in f:
        if line.strip():
            lines.append(line.strip())
        if len(lines) == 5:
            break
recs = [json.loads(l) for l in lines]
dup = json.loads(lines[0])                       # TC2: same user_id again
bad_ts = json.loads(lines[1]); bad_ts["user_id"] = 999000111
bad_ts["user_tweets"] = [dict(bad_ts["user_tweets"][0], created_at="not-a-date")]
test = lines[:5] + ['{{{', json.dumps(bad_ts)]       # 5 real, 1 malformed, 1 bad timestamp
path = "/tmp/loader_test.ndjson"
open(path, "w").write("\n".join(test) + "\n")

admin = psycopg2.connect(dbname="postgres", user="postgres", host="localhost"); admin.autocommit = True
c = admin.cursor(); c.execute("DROP DATABASE IF EXISTS botshield_test"); c.execute("CREATE DATABASE botshield_test"); admin.close()
here = os.path.dirname(os.path.abspath(__file__))
env = dict(os.environ, PGHOST="localhost", PGUSER="postgres")
subprocess.run(["psql", "-q", "-d", "botshield_test", "-f", os.path.join(here, "..", "db", "schema.sql")], env=env, check=True, capture_output=True)
out = subprocess.run([sys.executable, os.path.join(here, "..", "db", "load_data.py"), path, "botshield_test"], capture_output=True, text=True)
print("--- loader output ---"); print(out.stdout.strip()); print(out.stderr.strip())
conn = psycopg2.connect(dbname="botshield_test", user="postgres", host="localhost"); cur = conn.cursor()
cur.execute("SELECT count(*) FROM accounts"); a = cur.fetchone()[0]
cur.execute("SELECT count(*) FROM tweets"); t = cur.fetchone()[0]
cur.execute("SELECT count(*) FROM accounts WHERE external_user_id=999000111"); bad_acc = cur.fetchone()[0]
cur.execute("SELECT count(*) FROM tweets t JOIN accounts a ON a.id=t.account_id WHERE a.external_user_id=999000111"); bad_tw = cur.fetchone()[0]
cur.execute("SELECT count(*) FROM tweets WHERE posted_at IS NULL"); nulls = cur.fetchone()[0]
print(f"accounts in DB: {a}   tweets in DB: {t}   accounts with bad-timestamp id: {bad_acc}   its tweets: {bad_tw}   NULL posted_at rows: {nulls}")
