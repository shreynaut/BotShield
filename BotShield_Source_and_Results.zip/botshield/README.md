# BotShield: source code and results

Source code, SQL, analysis scripts and captured outputs for the paper
*BotShield: A Design and Preliminary Data Analysis for Transparent LLM-Powered Social Bot Risk Scoring*.

## What has and has not been run

| Component | Status |
|---|---|
| PostgreSQL schema (`db/schema.sql`) | Applied on PostgreSQL 16.15; log in `results/logs/01_schema.txt` |
| Python reference loader (`db/load_data.py`) | Run on the full dataset: 2,280 records, 111,905 tweets, 2,279 unique accounts, 0 errors, about 17 s (`02_load.txt`) |
| Loader fault-handling tests (`tests/run_loader_tests.py`) | Run; results in `03_loader_tests.txt` |
| Result queries (`sql/analysis_queries.sql`) | Run; reproduce Tables 2 and 3 (`04_results_queries.txt`) |
| Feature extraction, statistics, figures (`analysis/`) | Run; outputs in `results/` |
| Java / Spring Boot application (`src/`, `pom.xml`) | **Written but never compiled or run.** The build environment could not reach Maven Central. Treat it as untested until `mvn spring-boot:run` succeeds on your machine |
| Scoring engine, REST scoring endpoints, Thymeleaf dashboard | **Not implemented**, so there are no dashboard screenshots |

The screenshots in `results/screenshots/` are renderings of real console output
(the same text as `results/logs/`), not captures of a graphical application.

## Layout

```
pom.xml, src/main/java/com/botshield/   Spring Boot app: entities, repositories, sanity-check controller
db/schema.sql, db/load_data.py          schema and Python reference loader
sql/analysis_queries.sql                queries behind Tables 2 and 3
tests/run_loader_tests.py               loader fault-handling tests (Table 5)
analysis/features.py, stats.py, make_figures.py
results/logs/        console output of every run
results/screenshots/ the same output as images
results/figures/     Figs. 1-8 of the paper
results/*.csv        per-account features, hour-of-day data
```

## Reproduce

Requirements: PostgreSQL 16, Python 3 with `psycopg2-binary`, `pandas`, `numpy`, `scipy`, `matplotlib`.
Get `fox8-23-slim.ndjson` (the trimmed dataset, 50 tweets per account) and run:

```
createdb botshield
psql -d botshield -f db/schema.sql
python3 db/load_data.py fox8-23-slim.ndjson            # optional 2nd arg: database name
psql -d botshield -f sql/analysis_queries.sql
python3 tests/run_loader_tests.py fox8-23-slim.ndjson  # uses a scratch database botshield_test
python3 analysis/features.py fox8-23-slim.ndjson
python3 analysis/stats.py
python3 analysis/make_figures.py
```

The loader connects as user `postgres`, password `botshield`, host `localhost`; edit the connection
details at the top of `db/load_data.py` if yours differ.

## Notes from re-running the pipeline

- The loader now wraps each record in a savepoint, so one bad record is rolled back on its own and
  the rest of the load is kept. An earlier version let a single database error roll back the whole load.
- `tweets.posted_at` is nullable, so a tweet with an unparseable `created_at` is stored with a NULL
  timestamp (test case TC4).
- One user (ID 304679484) appears in two source subsets with the same label. The unique constraint
  keeps one account row, and the tweets of both records are attached to it (100 tweets). Its stored
  `tweet_count` is 50, taken from the first record, and is not recomputed. This is why the database holds
  2,279 accounts from 2,280 records.

## Data

fox8-23: K. Yang and F. Menczer, "Anatomy of an AI-powered malicious social botnet", JQD:DM 4, 2024
(Zenodo DOI 10.5281/zenodo.8035289).
