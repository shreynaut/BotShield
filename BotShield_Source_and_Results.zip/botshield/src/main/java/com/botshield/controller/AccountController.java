package com.botshield.controller;

import com.botshield.model.Account;
import com.botshield.repository.AccountRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * Phase-1 sanity-check endpoints only: confirms the JPA/Postgres wiring works
 * end to end against the real, already-loaded fox8-23 data. Scoring-related
 * endpoints (risk breakdown, flagged accounts) are added in later phases once
 * the scoring engine exists.
 */
@RestController
@RequestMapping("/api/accounts")
@RequiredArgsConstructor
public class AccountController {

    private final AccountRepository accountRepository;

    @GetMapping("/count")
    public Map<String, Long> count() {
        return Map.of(
                "total", accountRepository.count(),
                "bots", accountRepository.countByLabel("bot"),
                "humans", accountRepository.countByLabel("human")
        );
    }

    @GetMapping
    public Page<Account> list(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        return accountRepository.findAll(PageRequest.of(page, size));
    }

    @GetMapping("/{id}")
    public Account get(@PathVariable Long id) {
        return accountRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("No account with id " + id));
    }
}
