package com.botshield.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * A social media account under evaluation.
 * `label` carries ground truth (bot/human) from the source dataset, used only
 * for evaluation - it is never fed into the scoring model itself.
 */
@Entity
@Table(name = "accounts")
@Getter
@Setter
@NoArgsConstructor
public class Account {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "external_user_id", nullable = false, unique = true)
    private Long externalUserId;

    @Column(name = "label", nullable = false, length = 10)
    private String label; // "bot" | "human" - ground truth, evaluation only

    @Column(name = "source_dataset", nullable = false, length = 50)
    private String sourceDataset;

    @Column(name = "tweet_count", nullable = false)
    private Integer tweetCount = 0;

    @Column(name = "risk_score")
    private Double riskScore;

    @Column(name = "behavioral_score")
    private Double behavioralScore;

    @Column(name = "content_score")
    private Double contentScore;

    @Column(name = "network_score")
    private Double networkScore;

    @Column(name = "created_at", nullable = false)
    private OffsetDateTime createdAt = OffsetDateTime.now();

    @OneToMany(mappedBy = "account", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    private List<Tweet> tweets = new ArrayList<>();
}
