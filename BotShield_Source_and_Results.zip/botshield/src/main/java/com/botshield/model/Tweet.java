package com.botshield.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.OffsetDateTime;

@Entity
@Table(name = "tweets")
@Getter
@Setter
@NoArgsConstructor
public class Tweet {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "account_id", nullable = false)
    private Account account;

    @Column(name = "external_tweet_id", nullable = false)
    private Long externalTweetId;

    @Column(name = "posted_at", nullable = false)
    private OffsetDateTime postedAt;

    @Column(name = "text", columnDefinition = "TEXT")
    private String text;

    @Column(name = "retweet_count", nullable = false)
    private Integer retweetCount = 0;

    @Column(name = "favorite_count", nullable = false)
    private Integer favoriteCount = 0;

    @Column(name = "in_reply_to_status_id")
    private Long inReplyToStatusId;

    @Column(name = "hashtag_count", nullable = false)
    private Integer hashtagCount = 0;

    @Column(name = "url_count", nullable = false)
    private Integer urlCount = 0;

    @Column(name = "mention_count", nullable = false)
    private Integer mentionCount = 0;
}
